import json
from functions import main, list_files_from_s3, check_files_by_keyword, show_file_info_from_s3, delete_file_from_s3, delete_files_containing_keyword, process_data_by_keyword


def check_positive_number(number):
    return isinstance(number, (int, float)) and number > 0

def check_latitude_longitude_digit(latitude, longitude):
    try:
        float(latitude)
        float(longitude)
        return True
    except ValueError:
        return False

def check_latitude_longitude_range(latitude, longitude):
    try:
        latitude = float(latitude)
        longitude = float(longitude)
        if not (-90 <= latitude <= 90) or not (-180 <= longitude <= 180):
            return False
        return True
    except ValueError:
        return False

def parse_json_request(event):
    try:
        if "body" in event:
            body = event["body"]
            if isinstance(body, str):
                body = json.loads(body)
            if "data" in body:
                return body["data"], "data"
            elif "action" in body:
                return body, "action"
            return body, None  # If neither "data" nor "action" is present, return the body directly
    except Exception as e:
        print("An error occurred while parsing the JSON request:", e)
    return None, None

def lambda_handler(event, context):
    data, request_type = parse_json_request(event)
    
    if request_type == "action":
        action = data.get("action")
        if action == "list":
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': list_files_from_s3()
            }
        elif action == "parce":
            keyword = data.get("keyword", "").lower().strip()
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': check_files_by_keyword(keyword)
            }
        elif action == "show":
            file_name = data.get("file_name", "").lower().strip()
            response_body = show_file_info_from_s3(file_name)
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps(response_body)
            }
        elif action == "delete":
            file_name_to_delete = data.get("file_name", "").lower().strip()
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': delete_file_from_s3(file_name_to_delete)
            }
        elif action == "delete by keyword":
            keyword_delete = data.get("keyword", "").lower().strip()
            result = delete_files_containing_keyword(keyword_delete)
            if result:
                response_body = f"Files with keyword '{keyword_delete}' deleted from S3 successfully."
            else:
                response_body = f"Error: Unable to delete files containing '{keyword_delete}'. No files found."
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps(response_body)
            }
        elif action == "save by keyword":
            keyword_save = data.get("keyword", "").lower().strip()
            result = process_data_by_keyword(keyword_save)
            if result:
                response_body = f"File '{result}' created and saved to S3 successfully."
            else:
                response_body = "Error: Unable to create and save file to S3."
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps(response_body)
            }
        else:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps("Error: Invalid action specified.")
            }
    elif request_type == "data":
        latitude = data.get("lat")
        longitude = data.get("lon")
        radius = data.get("radius")
        place_type = data.get("place_type", "").lower().strip()

        # Check if latitude, longitude, and radius are provided
        if latitude is not None and longitude is not None and radius is not None:
            # Check if radius is a positive number
            if not check_positive_number(radius):
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                        'Access-Control-Allow-Methods': 'POST',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps("Error: Radius must be a positive number.")
                }
            # Check if latitude and longitude are digits and within valid range
            if not check_latitude_longitude_digit(latitude, longitude) or not check_latitude_longitude_range(latitude, longitude):
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                        'Access-Control-Allow-Methods': 'POST',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps("Error: Latitude and longitude must be valid decimal numbers between -90 and 90 for latitude, and -180 and 180 for longitude.")
                }
            # Handle saving content without or with keyword
            if "no_keyword" in data:
                no_keyword = data.get("no_keyword", "").lower().strip()
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                        'Access-Control-Allow-Methods': 'POST',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps(main(radius, latitude, longitude, place_type, no_keyword=no_keyword))
                }
            elif "keyword" in data:
                keyword = data.get("keyword", "").lower().strip()
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                        'Access-Control-Allow-Methods': 'POST',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps(main(radius, latitude, longitude, place_type, keyword))
                }
            else:
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                        'Access-Control-Allow-Methods': 'POST',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps(main(radius, latitude, longitude, place_type))
                }
        else:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                    'Access-Control-Allow-Methods': 'POST',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps("Error: Latitude, longitude, or radius is missing in the request.")
            }
    else:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
                'Access-Control-Allow-Methods': 'POST',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps("Error: Invalid request format.")
        }
