import datetime
import os
import requests
import boto3
import math

# AWS credentials and bucket name
bucket_name = os.environ.get("BUCKET_NAME")

# Google API Key
api_key = os.environ.get("API_KEY")


places_with_distance = []

def get_nearby_places(api_key, latitude, longitude, radius, place_type):
    try:
        params = {
            'key': api_key,
            'location': f"{latitude},{longitude}",
            'radius': radius,
            'type': place_type
        }
        response = requests.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json', params=params)
        data = response.json()
        if 'results' in data:
            return data['results']
        else:
            return []
    except requests.exceptions.RequestException as e:
        print("An error occurred during the request:", e)
        return []

def check_s3_connection():
    try:
        s3 = boto3.client('s3')
        response = s3.list_buckets()
        return s3
    except Exception as e:
        print("An error occurred while connecting to S3:", e)
        return None

def save_to_s3(data, file_name):
    s3 = check_s3_connection()
    if s3 is None:
        return False
    try:
        csv_data = "\n".join([",".join(map(str, row)) for row in data])
        s3.put_object(Body=csv_data.encode('utf-8'), Bucket=bucket_name, Key=file_name)
        return True
    except Exception as e:
        print("An error occurred while saving to S3:", e)
        return False

def filter_places_by_keyword(data, keyword):
    """Filter places by a keyword.

    Args:
        data (list): List of tuples containing place information.
        keyword (str): Keyword to filter places.

    Returns:
        list: Filtered list of tuples.
    """
    if keyword is None:
        return data
    filtered_data = [row for row in data if keyword.lower() in row[0].lower()]
    if not filtered_data:
        print(f"No places containing '{keyword}' found in the list.")
    return filtered_data


def list_files_from_s3():
    s3 = check_s3_connection()
    if not s3:
        return "Failed to connect to S3."

    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        if 'Contents' in response:
            file_list = [obj['Key'] for obj in response['Contents']]
            return '\n'.join(file_list)
        else:
            return "No files found in the S3 bucket."
    except Exception as e:
        return f"An error occurred while listing files from S3: {e}"



def show_file_info_from_s3(file_name):
    s3 = check_s3_connection()
    if not s3:
        return "Failed to connect to S3."

    try:
        obj = s3.get_object(Bucket=bucket_name, Key=file_name)
        file_content = obj['Body'].read().decode('utf-8')
        data = []
        for line in file_content.split('\n'):
            if line:
                name, lat, lng, distance = line.split(',')
                data_info = {
                    "Name": name,
                    "Latitude": float(lat),
                    "Longitude": float(lng),
                    "Distance": float(distance)
                }
                data.append(data_info)
        return data
    except s3.exceptions.NoSuchKey:
        return "Error: File not found. Please enter a correct file name."
    except Exception as e:
        return f"An error occurred while retrieving file info from S3: {e}"

def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371  # Radius of the Earth in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) * math.sin(dlat / 2) + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) * math.sin(dlon / 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance = R * c
    return round(distance, 3)  # Round to 3 decimal places

def check_files_by_keyword(keyword):
    s3 = check_s3_connection()
    if not s3:
        return "Failed to connect to S3."

    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        files_with_keyword = []

        if 'Contents' in response:
            for file in response['Contents']:
                file_name = file['Key']
                file_content = s3.get_object(Bucket=bucket_name, Key=file_name)['Body'].read().decode('utf-8')
                if keyword.lower() in file_content.lower():
                    files_with_keyword.append(file_name)

        if files_with_keyword:
            return '\n'.join(files_with_keyword)
        else:
            return f"No files containing the keyword '{keyword}' found."
    except Exception as e:
        return f"An error occurred: {e}"

def delete_file_from_s3(file_name):
    s3 = check_s3_connection()
    if not s3:
        return "Failed to connect to S3."

    try:
        s3.head_object(Bucket=bucket_name, Key=file_name)
        s3.delete_object(Bucket=bucket_name, Key=file_name)
        return f"File '{file_name}' deleted successfully."
    except s3.exceptions.ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == '404':
            return f"Error: File '{file_name}' not found."
        else:
            return f"An error occurred while deleting file '{file_name}': {e}"
    except Exception as e:
        return f"An error occurred while deleting file '{file_name}': {e}"

def delete_files_containing_keyword(keyword):
    s3 = check_s3_connection()
    if not s3:
        return False  # Return False if failed to connect to S3

    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        files_with_keyword = []

        if 'Contents' in response:
            for file in response['Contents']:
                file_name = file['Key']
                file_content = s3.get_object(Bucket=bucket_name, Key=file_name)['Body'].read().decode('utf-8')
                if keyword.lower() in file_content.lower():
                    files_with_keyword.append(file_name)

        if files_with_keyword:
            for file_name in files_with_keyword:
                try:
                    s3.delete_object(Bucket=bucket_name, Key=file_name)
                    print(f"File '{file_name}' containing the keyword '{keyword}' deleted successfully.")
                except s3.exceptions.ClientError as e:
                    error_code = e.response['Error']['Code']
                    if error_code == '404':
                        print(f"Error: File '{file_name}' not found.")
                    else:
                        print(f"An error occurred while deleting file '{file_name}': {e}")
            return True  # Return True if deletion was successful
        else:
            print(f"No files containing the keyword '{keyword}' found.")
            return False  # Return False if no files were found with the keyword
    except Exception as e:
        print(f"An error occurred: {e}")
        return False  # Return False if an error occurs

def process_data_by_keyword(keyword):
    s3 = check_s3_connection()
    if not s3:
        print("Failed to connect to S3.")
        return None  # Return None when failed to connect to S3

    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        files_with_keyword = []

        if 'Contents' in response:
            for file in response['Contents']:
                file_name = file['Key']
                file_content = s3.get_object(Bucket=bucket_name, Key=file_name)['Body'].read().decode('utf-8')
                if keyword.lower() in file_content.lower():
                    files_with_keyword.append((file_name, file_content))

        if files_with_keyword:
            # Generate timestamp for the file name
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            new_file_name = f"files_info_{keyword}_{timestamp}.csv"
            csv_data = "\n".join([",".join(map(str, row)) for row in files_with_keyword])
            s3.put_object(Body=csv_data.encode('utf-8'), Bucket=bucket_name, Key=new_file_name)
            print(f"File '{new_file_name}' created and saved to S3 successfully.")
            return new_file_name  # Return the filename upon successful saving
        else:
            print(f"No files containing the keyword '{keyword}' found.")
            return None  # Return None when no files are found with the keyword
    except Exception as e:
        print(f"An error occurred: {e}")
        return None  # Return None when an error occurs

def main(radius, latitude, longitude, place_type, keyword=None, no_keyword=None):
    s3 = check_s3_connection()
    if not s3:
        return "Failed to connect to S3."

    global places_with_distance

    location = (float(latitude), float(longitude))
    radius = float(radius)

    nearby_places = get_nearby_places(api_key, latitude, longitude, radius, place_type)

    if nearby_places:
        print("{:<20} {:<20} {:<20} {:<20}".format("Name", "Latitude", "Longitude", "Distance"))

        places_with_distance = []
        for place in nearby_places:
            name = place.get('name')
            lat = round(place['geometry']['location']['lat'], 6)
            lng = round(place['geometry']['location']['lng'], 6)
            distance = haversine_distance(latitude, longitude, lat, lng)
            places_with_distance.append((name, lat, lng, distance))

        # Sort places by distance
        places_with_distance.sort(key=lambda x: x[3])

        formatted_places = []
        for place_info in places_with_distance:
            name, lat, lng, distance = place_info
            formatted_place = {"Name": name, "Latitude": lat, "Longitude": lng, "Distance": distance}
            formatted_places.append(formatted_place)

        # Save data to S3
        now = datetime.datetime.now()
        date_time_str = now.strftime("%d-%m-%Y_%H-%M")

        if keyword:
            # Save content with keyword
            with_keyword_file_name = f"with_{keyword}_{date_time_str}.csv"
            filtered_places = filter_places_by_keyword(places_with_distance, keyword)
            if filtered_places:
                if save_to_s3(filtered_places, with_keyword_file_name):
                    print(f"Save content with keyword: {with_keyword_file_name}")
                    formatted_places.append({"Save all content": with_keyword_file_name})
                else:
                    print("Failed to save content with keyword")
            else:
                print(f"No places containing '{keyword}' found. Skipping saving content with keyword.")

        elif no_keyword:
            # Save content without keyword
            without_keyword_file_name = f"without_{no_keyword}_{date_time_str}.csv"
            filtered_places = [place for place in places_with_distance if no_keyword.lower() not in place[0].lower()]
            if filtered_places:
                if save_to_s3(filtered_places, without_keyword_file_name):
                    print(f"Save content without keyword: {without_keyword_file_name}")
                    formatted_places.append({"Save all content": without_keyword_file_name})
                else:
                    print("Failed to save content without keyword")
            else:
                print(f"No places without '{no_keyword}' found. Skipping saving content without keyword.")

        else:
            # Save all content
            all_file_name = f"all_{place_type.lower().replace(' ', '_')}_{date_time_str}.csv"
            if save_to_s3(places_with_distance, all_file_name):
                print(f"Save all content: {all_file_name}")
                formatted_places.append({"Save all content": all_file_name})
            else:
                print("Failed to save all content")

        return formatted_places
    else:
        return "No nearby places found."

